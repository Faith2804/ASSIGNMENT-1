
//calculating the number of processors available
public class iii{

 public static void main(String[] args)
 {
 
   Runtime run=Runtime.getRuntime();
   int num=run.availableProcessors();
   
   System.out.println(num); 
 }
}